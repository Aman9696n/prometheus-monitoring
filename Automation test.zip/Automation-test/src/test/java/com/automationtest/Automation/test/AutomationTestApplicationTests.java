package com.automationtest.Automation.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
