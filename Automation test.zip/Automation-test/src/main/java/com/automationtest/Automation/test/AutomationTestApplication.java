package com.automationtest.Automation.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationTestApplication.class, args);
	}

}
